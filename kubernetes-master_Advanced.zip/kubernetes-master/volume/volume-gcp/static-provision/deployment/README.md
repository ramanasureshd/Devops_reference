In case of static provisioning the disk has to be created before creating pod or deployment

![21](https://user-images.githubusercontent.com/29688323/108598553-3e368500-73b4-11eb-8678-74114ea6efa6.JPG)
